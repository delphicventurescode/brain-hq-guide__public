# Chapter 1: Welcome to Headquarters

## The Big Idea: You are the Head Operator
Have you ever stopped to think about what is happening inside your head? Right now, as you read this, your brain is processing thousands of thoughts, memories, and feelings. It is the most powerful, complex supercomputer in the known universe. 

And here is the best part: You are the Head Operator.

Often, it feels like our emotions are in charge. When we feel sad, we think we *are* sad. When we feel angry, we think we *are* angry. But being the Head Operator means realizing that **you are not your emotions.** You are the person sitting in the control room watching those emotions happen. 

## The Control Room
Imagine a giant room filled with screens, buttons, and levers. Each screen shows a different part of your life: school, friends, your family, your hobbies, and your future. Sometimes, one screen starts flashing red because you’re stressed about a test. Sometimes, a screen is glowing gold because you’re having fun with a friend.

When you were younger, it might have felt like the buttons were being pushed by someone else. But as you get older—at 10 and 11 years old—you are getting a promotion. You are stepping into the "Head Operator" chair. This book is your official Field Guide to that console. 

## Why This Matters
Mental wellness isn't about being happy 100% of the time—that’s impossible, even for the happiest people on Earth! Instead, mental wellness is about knowing how to navigate the control room. It’s about knowing which buttons to push when you’re overwhelmed, how to turn down the volume on the "stress" alarms, and how to maximize the "joy" signals.

## Quick Check-In: Your Current Status
Before we start, let's calibrate your console. Don't overthink it; just pick the one that feels most like your brain right now:

* **System Check:** [ ] Everything is green and running smooth.
* **Glitch Detected:** [ ] Feeling a bit confused or overwhelmed.
* **Low Battery:** [ ] Feeling tired, bored, or just "blah."

*Whatever your status, remember: The first step to being a great operator is just noticing what’s happening on your screens.*
