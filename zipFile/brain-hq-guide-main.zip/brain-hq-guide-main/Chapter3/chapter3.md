# Chapter 3: Emotion Detective

## The Big Idea: Emotions are Data, Not Orders
Imagine you are driving a car and a red light starts flashing on the dashboard. Do you panic? Do you scream at the car? No! You look at the manual to see what that light means. It’s "data"—it’s telling you that you’re low on gas or need an oil change.

Your emotions are exactly the same. 

## The 15-Emotion Palette
Psychologists have identified many emotions, but let’s focus on these 15:
* **The 9 "Dashboard Alerts" (Negative Emotions):** Sadness, Anger, Fear, Guilt, Shame, Boredom, Jealousy, Loneliness, and Disgust.
* **The 6 "Power-Ups" (Positive Emotions):** Joy, Interest, Contentment, Hope, Pride, and Love.

Here is the secret: **None of these are "bad" or "good."** They are just signals. 
* **Fear** tells you: "Be careful, something might be dangerous."
* **Anger** tells you: "Something isn't fair; stand up for yourself."
* **Sadness** tells you: "You lost something you care about; take time to heal."

## The Detective’s Method
When you feel a strong emotion, don't just react. Become a detective:

1.  **Stop and Name It:** Instead of saying "I'm a mess," say, "I am feeling frustrated." Naming it makes it smaller.
2.  **Ask "Why?":** What caused this? Did someone say something unkind? Are you tired? Did you fail at a challenge?
3.  **Check the Signal:** What is this emotion trying to tell me? Is there a problem I need to fix, or do I just need to be kind to myself while the feeling passes?

## The Shift
Once you understand the signal, you can move toward the "Power-Up" emotions. If you’re bored (a signal), you might choose to *do* something that sparks "Interest" (a power-up). If you’re lonely (a signal), you might reach out to a friend to feel "Love" or "Connection." 

**Detective’s Journal Entry:**
The next time you feel a strong "dashboard alert" emotion, write down:
* What I felt:
* What it was telling me:
* One "Power-Up" I can try:
