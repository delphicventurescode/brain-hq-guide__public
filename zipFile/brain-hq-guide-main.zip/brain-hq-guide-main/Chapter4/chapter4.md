# Chapter 4: The Lab Report

## The Big Idea: Data-Driven Happiness
You’ve learned about the 40% of happiness you control. Now, it’s time to run some experiments! These six exercises are proven by Positive Psychology to boost your baseline happiness. Treat these as your "Weekly Lab Tasks."

### 1. The Gratitude Three
Every night, write down three specific things that went well today. Don’t just say "my friends." Say, "My friend Sam shared his sandwich." Specifics build better neural pathways!

### 2. The Kindness Catalyst
Do one deliberate act of kindness for someone else. It could be helping with chores or giving a genuine compliment. It releases "feel-good" chemicals in your brain.

### 3. The Savoring Stop
Pick one moment today—eating a favorite snack, playing with a pet, or watching a sunset—and pause. Really notice the colors, sounds, and feelings. This "freezes" the happy moment in your memory.

### 4. The Growth Mindset Shift
When you fail at something, don't say "I'm bad at this." Say, "I'm not good at this *yet*." This exercise changes your brain from "fixed" to "growing."

### 5. Strengths Spotlight
Identify one thing you are naturally good at (like drawing, logic, or being a good listener) and use that skill to help someone else.

### 6. The "Best Self" Visual
Spend 5 minutes imagining your best possible future self—the person you want to be. Research shows that visualizing your goals makes you more likely to achieve them.



*Assignment: Pick ONE exercise to perform every day this week. Track your "happiness score" at the end of the week.*
