# Chapter 2: The Happiness Pie Chart

## The Big Idea: The 40-10-50 Secret
Have you ever met someone who seems happy no matter what happens? Or someone who always seems to find something to complain about? We often think happiness is just luck—the "luck of the draw." But research by scientists, specifically Dr. Sonja Lyubomirsky and others in the field of Happiness Studies (yes, it is a real area of study), has revealed that happiness is more like a science experiment than a lottery.

If we took your total potential for happiness and turned it into a pie chart, here is how the slices break down:

### 1. The "Factory Setting" (50%)
About half of your happiness is determined by your genetics—the traits you were born with. Some people are just naturally more upbeat, while others are naturally a bit more serious. This is like the hardware your brain was built with. You didn't choose it, and you can't really change it.

### 2. Your Circumstances (10%)
This is where you live, what school you go to, the money your family has, or the gifts you get for your birthday. While these things definitely impact your mood, they make up a much smaller slice of the pie than most people think. Even if you got everything on your wish list, the "happiness boost" from it usually fades pretty quickly.

### 3. Your Choices (40%)
**This is the most important part of this book.** 40% of your happiness is entirely up to you. It is determined by the habits you build, the way you think about problems, and the actions you take every single day. 

## Why 40% is Huge
If you have a 100-point scale for happiness, this means 40 points are sitting right there in your hands. You don't need to change your personality (the 50%) or wait for your life to become perfect (the 10%). You just need to learn how to use your 40% effectively.

## The Mission
Think of this as your "Happiness Budget." Every day, you have a chance to invest in that 40%. Some days you might invest a lot, and some days you might forget. That’s okay! The goal isn't to be perfect; the goal is to be intentional.

**Challenge:** Look at your day yesterday. Can you think of one thing you did that made you feel proud, connected, or happy? That was you using your 40%!
